<!DOCTYPE html>
<html>
<head>
	<title>Urban Muse</title>
	<!-- link to _css/styles.css here -->
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
		<link rel= "stylesheet" href="_css/styles.css"/>
		<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
	<body>

		<body background="_img/WebHome.jpg">
		<body background="_img/body.jpg">
		<body background="_img/DivContent.jpg">


		<div id="container">
		<header>
			<img class="_img/Header.jpg" height="290" width="1140">
		</header>


		<nav>
				<a href="home.php" class="chosen">HOME</a>
				<a href="about.php">ABOUT</a>
				<a href="pics.php">PICS</a>
				<a href="contact.php">CONTACT</a>
		</nav>


		<div id="main" class="cf">
		<article>
			<h1>Portfolio</h1>
				<div class="container-fluid">

				<div class="row">
				<div class="col-xs-12 col-sm-5 col-md-4 col-lg-2">
				<img src="_img/gallery/IMG1.jpg" height="250" width="250">
				</div>
			</div>

				<div class="row">
				<div class="col-xs-12 col-sm-5 col-md-4 col-lg-2">
				<img src="_img/gallery/IMG2.jpg" height="250" width="250">
				</div>
			</div>

				<div class="row">
				<div class="col-xs-12 col-sm-5 col-md-4 col-lg-2">				
				<img src="_img/gallery/IMG3.jpg" height="250" width="250">
				</div>
			</div>

				<div class="row">
				<div class="col-xs-12 col-sm-5 col-md-4 col-lg-2">				
				<img src="_img/gallery/IMG4.jpg" height="250" width="250">
				</div>
			</div>

				<div class="row">
				<div class="col-xs-12 col-sm-5 col-md-4 col-lg-2">				
				<img src="_img/gallery/IMG5.jpg" height="250" width="250">
				</div>
			</div>

				<div class="row">
				<div class="col-xs-12 col-sm-5 col-md-4 col-lg-2">									
				<img src="_img/gallery/IMG6.jpg" height="250" width="250">
				</div>
			</div>

				<div class="row">
				<div class="col-xs-12 col-sm-5 col-md-4 col-lg-2">				
				<img src="_img/gallery/IMG7.jpg" height="250" width="250">
				</div>
			</div>

				<div class="row">
				<div class="col-xs-12 col-sm-5 col-md-4 col-lg-2">				
				<img src="_img/gallery/IMG8.jpg" height="250" width="250">
				</div>
			</div>


		</div>
					
		</article>
         </div>
            
			<footer>FOOTER</footer>
		</div>
		<script src="_js/jquery-1.11.3.min.js"></script>
		<script src="js/bootstrap.min.js">
		</script>
		<!-- link to _js/scripts.js -->
		<script src="_js/scripts.js"></script>
		<script src="responsiveslides.min.js"></script>

	</body>
</html>