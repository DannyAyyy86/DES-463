<!DOCTYPE html>
<html>
	<head>
		<title>Urban Muse</title>
			<!-- Links Here. -->
			<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
			<link rel="stylesheet"  href="_css/styles.css">
			<meta name="viewport" content="width=device-width, initial-scale=1">
	</head>

	<body>

		<body background="_img/WebHome.jpg">
		<body background="_img/body.jpg">
		<body background="_img/DivContent.jpg">


		<div id="container">
		<header>
			<img class="_img/Header.jpg" height="290" width="1140">
		</header>

		<nav>
				<a href="home.php" class="chosen">HOME</a>
				<a href="about.php">ABOUT</a>
				<a href="pics.php">PICS</a>
				<a href="contact.php">CONTACT</a>
		</nav>

		<div id="main" class="cf">
				<article>
					<h1>Home</h1>
					<p>
					Welcome to Urban Muse. A place where many people do not know about the
					life that is lived. Many people think of it as being rough and dirty. What
					do not know is that urban is not all bad. It is all about the world of art
					and music. Urban Muse is a site that takes people into the world of 
					inspiration, fashion trends, song, and more. You will be suprised on what 
					you can discover.
					</p>
					<p>
					Hip Hop is the most vibarant and cultural art you'll ever come across.
					Respect that.
					</p>
					<p>
					Hip hop is more than just music. Hip Hop has crossed cultural boundaries
					that other music generes  never crossed. Hip Hop is not only the music you
					listen to. But the way you walk, talk, dress and act. Hip Hop is a state of 
					mind. An entire generation.  
					</p>
				</article>

				<aside>
				<h1>Aside</h1>

				<img src="_img/AsideSpot.jpg" height="500" width="500">

				</aside>
			</div>

			<footer>FOOTER</footer>
		</div>
		<script src="_js/jquery-1.11.3.min.js"></script>
		<script src="js/bootstrap.min.js">
		</script>
		<!-- link to _js/scripts.js -->
		<script src="_js/scripts.js"></script>
		<script src="responsiveslides.min.js"></script>

</body>
	</html>