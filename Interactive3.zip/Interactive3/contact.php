<!DOCTYPE html>
<html>
	<head>
		<title>Project Recreation</title>
		<!-- Links Here. -->
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
		<link rel= "stylesheet" href="_css/styles.css"/>
		<meta name="viewport" content="width=device-width, initial-scale=1">
</head>

	<body>

		<body background="_img/WebHome.jpg">
		<body background="_img/body.jpg">
		<body background="_img/DivContent.jpg">


		<div id="container">
		<header>
			<img class="_img/Header.jpg" height="290" width="1140">
		</header>


		<nav>
				<a href="home.php" class="chosen">HOME</a>
				<a href="about.php">ABOUT</a>
				<a href="pics.php">PICS</a>
				<a href="contact.php">CONTACT</a>
		</nav>


		<div id="main" class="cf">
			<article>
			<h1>Contact</h1>

			<form>
			  <div class="form-group">
			    <label for="exampleInputEmail1">Email address</label>
			    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Email">
			  </div>
			  <div class="form-group">
			    <label for="exampleInputPassword1">Password</label>
			    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
			  </div>
			  <div class="form-group">
			    <label for="exampleInputFile">File input</label>
			    <input type="file" id="exampleInputFile">
			    <p class="help-block">Example block-level help text here.</p>
			  </div>
			  <div class="checkbox">
			    <label>
			      <input type="checkbox"> Check me out
			    </label>
			  </div>
			  <button type="submit" class="btn btn-default">Submit</button>
			</form>


			<form class="form-inline">
			  <div class="form-group">
			    <label for="exampleInputName2">Name</label>
			    <input type="text" class="form-control" id="exampleInputName2" placeholder="Jane Doe">
			  </div>
			  <div class="form-group">
			    <label for="exampleInputEmail2">Email</label>
			    <input type="email" class="form-control" id="exampleInputEmail2" placeholder="jane.doe@example.com">
			  </div>
			  <button type="submit" class="btn btn-default">Send invitation</button>
			</form>

			</article>

			<aside>
				<h1>Aside</h1>

				<img src="">

			</aside>
		</div>

			<footer>FOOTER</footer>
		</div>
		<script src="_js/jquery-1.11.3.min.js"></script>
		<script src="js/bootstrap.min.js">
		</script>
		<!-- link to _js/scripts.js -->
		<script src="_js/scripts.js"></script>
		<script src="responsiveslides.min.js"></script>

		</body>
	</html>