<!DOCTYPE html>
<html>
	<head>
	<title>Project Recreation</title>
		<!-- Links Here. -->
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
		<link rel= "stylesheet" href="_css/styles.css"/>
		<meta name="viewport" content="width=device-width, initial-scale=1">

	</head>
		<body>

			<body background="_img/WebHome.jpg">
			<body background="_img/body.jpg">
			<body background="_img/DivContent.jpg">


		<div id="container">
		<header>
			<img class="_img/Header.jpg" height="290" width="1140">
		</header>

		<nav>
				<a href="home.php" class="chosen">HOME</a>
				<a href="about.php">ABOUT</a>
				<a href="pics.php">PICS</a>
				<a href="contact.php">CONTACT</a>
		</nav>

		<div id="main" class="cf">
				<article>
					<h1>Home</h1>
					<p>
					In the light of our culture, these are not unreasonable 
					questions and tactics. But if once again, we try to see the lens
					through which we look, we can see that there is too far great of an
					emphasis placed on the future.
					</p>
					<p>
					I'm selfish, impatient and a little insecure. I make mistakes, I am out
					of control and at times hard to handle. But if you can't handle me at my
					worse, then you sure as hell don't deserve me at my best.
					</p>
					<p>
					I trained my ego to see gold, see no seagulls could've see the goals.  
					</p>
				</article>

				<aside>
				<h1>Aside</h1>

				<img src="_img/AboutBabe.jpg">

				</aside>
			</div>

			<footer>FOOTER</footer>
		</div>
		<script src="_js/jquery-1.11.3.min.js"></script>
		<script src="js/bootstrap.min.js">
		</script>
		<!-- link to _js/scripts.js -->
		<script src="_js/scripts.js"></script>
		<script src="responsiveslides.min.js"></script>

	</body>
</html>